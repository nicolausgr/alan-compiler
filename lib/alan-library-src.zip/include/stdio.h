void   writeInteger (int n);
void   writeByte    (byte b);
void   writeBoolean (bool b);
void   writeChar    (char c);
void   writeReal    (double d);
void   writeString  (char * s);

int    readInteger  ();
byte   readByte     ();
bool   readBoolean  ();
char   readChar     ();
double readReal     ();

void   readString   (int size, char * s);
