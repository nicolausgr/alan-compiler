int  strlen (char * s);
int  strcmp (char * s1, char * s2);
void strcpy (char * trg, char * src);
void strcat (char * trg, char * src);
