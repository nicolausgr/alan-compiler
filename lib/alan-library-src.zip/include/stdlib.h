int  trunc  (double d);
int  round  (double d);

int  ord    (char c);
char chr    (int n);

void exit   (int code);

byte shrink (int i);
int  extend (byte b);
