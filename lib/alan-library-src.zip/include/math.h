int    abs  (int n);
double fabs (double d);

double sqrt (double d);
double sin  (double d);
double cos  (double d);
double tan  (double d);
double atan (double d);
double exp  (double d);
double ln   (double d);
double pi   ();
